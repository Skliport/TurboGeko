/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consultas;

import entidades.Purchase_suppliers;
import entidades.Purchase_suppliers_details;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author William
 */
public class Con_purchase_supplier_detail extends Conexion {

    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

    public void getlistpurchase_supplier_details(DefaultTableModel modelorder_pursup, String buscar) {
//        DefaultTableModel modeloventas = (DefaultTableModel) frames.MnBaseAdmin.tablaVenta.getModel();
//        while (modeloventas.getRowCount() > 0) {
//            modeloventas.removeRow(0);
//        }
        String sql = "";
        sql = "SELECT * FROM list_purchase_supplier_detail('" + buscar + "')";

        Purchase_suppliers_details purcha_sup_det = null;
        ArrayList< Purchase_suppliers_details>li_purc_sup_det               = new ArrayList();
        try {
            Statement st = super.getConexion().createStatement();
            ResultSet rs = st.executeQuery(sql); 
            while (rs.next()) {
                purcha_sup_det = new Purchase_suppliers_details();
                purcha_sup_det.setPurchase_suppliers_details(rs.getInt("purchase_suppliers_details"));
                purcha_sup_det.setMaterial_name(rs.getString("material_name"));
                purcha_sup_det.setQuantity(rs.getInt("quantity"));
                  purcha_sup_det.setUnit_price(rs.getDouble("unit_price"));
                li_purc_sup_det.add(purcha_sup_det);
            }
            double total;
            for (Purchase_suppliers_details pr : li_purc_sup_det) {
                total= pr.getQuantity() * pr.getUnit_price();
                String obpro[] = {Integer.toString(pr.getPurchase_suppliers_details()) ,pr.getMaterial_name(),
                Double.toString(pr.getUnit_price()),Integer.toString(pr.getQuantity()),Double.toString(pr.getQuantity() * pr.getUnit_price())}; 
                modelorder_pursup.addRow(obpro);
                System.out.println("mostrando");
            }

        } catch (SQLException ex) {
            System.out.println("error:" + ex);
        }
    }

}
