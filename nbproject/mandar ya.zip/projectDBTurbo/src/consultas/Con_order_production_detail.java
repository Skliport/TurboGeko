/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consultas;

import entidades.Order_production_detail;
import entidades.Sale;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author William
 */
public class Con_order_production_detail extends Conexion{
 
    
    public void getlistorder_production_detail(DefaultTableModel modelsales,String buscar) {
//        DefaultTableModel modeloventas = (DefaultTableModel) frames.MnBaseAdmin.tablaVenta.getModel();
//        while (modeloventas.getRowCount() > 0) {
//            modeloventas.removeRow(0);
//        }
         String sql = "";
        sql = "SELECT * FROM listorder_production_detail_filter('" + buscar + "')";

        Order_production_detail ordprod_detail = null;
        ArrayList<Order_production_detail> li_prod_detail = new ArrayList();
        try {
            Statement st = super.getConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ordprod_detail = new  Order_production_detail();
                ordprod_detail.setId_order_production_detail(rs.getInt("order_production_detail_id"));
                ordprod_detail.setProduct_name(rs.getString("name_product"));
                ordprod_detail.setQuantity(rs.getDouble("quantity")); 
                ordprod_detail.setUnit_price(rs.getDouble("unit_price"));
                li_prod_detail.add(ordprod_detail);
            }

            for (Order_production_detail  pr : li_prod_detail) {
                String obpro[] = {Integer.toString(pr.getId_order_production_detail()),pr.getProduct_name(),Double.toString(pr.getQuantity()),
                Double.toString(pr.getUnit_price())}; 
                modelsales.addRow(obpro);  
            }

        } catch (SQLException ex) {
            System.out.println("error:" + ex);
        }
    }
    
     public void  getlistorder_production_detailk( DefaultTableModel modelsale) {

//        DefaultTableModel modeloventas = (DefaultTableModel) frames.MnBaseAdmin.tablaVenta.getModel();
//        while (modeloventas.getRowCount() > 0) {
//            modeloventas.removeRow(0);
//        }
        String sql = "";
        sql = "select * from list_sales()";

        Sale vent = null;
        ArrayList<Sale> liventa = new ArrayList();
        try {
            Statement st = super.getConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                vent = new Sale();
                vent.setId_sale(rs.getInt("id_sale"));
                vent.setNum_invoice(rs.getString("num_invoice"));
                vent.setStatus_sale(rs.getInt("status_sale")); 
                vent.setDate_sale(rs.getString("date_sale"));
                vent.setShip_date(rs.getString("ship_date"));
                vent.setDocument_type(rs.getInt("document_type")); 
                vent.setSubtotal(rs.getDouble("sub_total"));
                vent.setTax(rs.getDouble("tax"));
                vent.setTotal(rs.getDouble("total"));
                vent.setObservation(rs.getString("observations"));
//                vent.setId_sale(rs.getInt(""));
                liventa.add(vent);
            }

            for (Sale pr : liventa) {
                if (pr.getStatus_sale()==1) {
                String obpro[] = {Integer.toString(pr.getId_sale()),"cancelado", pr.getDate_sale(),
                Double.toString(pr.getSubtotal()),Double.toString(pr.getTax()),Double.toString(pr.getTotal())}; 
                modelsale.addRow(obpro);   
                }
                else{
                String obpro[] = {Integer.toString(pr.getId_sale()),"sin pago", pr.getDate_sale(),
                Double.toString(pr.getSubtotal()),Double.toString(pr.getTax()),Double.toString(pr.getTotal())}; 
                modelsale.addRow(obpro); 
                }
            }

        } catch (SQLException ex) {
            System.out.println("error:" + ex);
        }
    }
}
