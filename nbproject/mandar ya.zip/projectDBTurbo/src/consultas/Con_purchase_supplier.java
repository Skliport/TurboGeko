/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consultas;

import entidades.Order_production;
import entidades.Purchase_suppliers;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author William
 */
public class Con_purchase_supplier extends Conexion{
    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

    public void getlistpurchase_supplier_filter(DefaultTableModel modelorder_pursup, String buscar) {
//        DefaultTableModel modeloventas = (DefaultTableModel) frames.MnBaseAdmin.tablaVenta.getModel();
//        while (modeloventas.getRowCount() > 0) {
//            modeloventas.removeRow(0);
//        }
        String sql = "";
        sql = "SELECT * FROM list_purchase_supplier_filter('" + buscar + "')";
             Purchase_suppliers purcha_sup = null;
        ArrayList< Purchase_suppliers> li_purc_sup = new ArrayList();
        try {
            Statement st = super.getConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                purcha_sup = new  Purchase_suppliers();
                 purcha_sup.setPurchase_id(rs.getInt("purchase_id"));
                purcha_sup.setPurchase_date(rs.getDate("purchase_date"));
                purcha_sup.setPurchase_status(rs.getInt("purchase_status"));
                purcha_sup.setObservation(rs.getString("observations"));
                purcha_sup.setSubtotal(rs.getDouble("subtotal"));
                purcha_sup.setIva(rs.getDouble("iva"));
                purcha_sup.setTotal(rs.getDouble("total"));
               li_purc_sup.add(purcha_sup);
            }

            for (Purchase_suppliers pr : li_purc_sup) {  
                    String obpro[] = {Integer.toString(pr.getPurchase_id()), sdf.format(pr.getPurchase_date()),
                    Double.toString(pr.getIva()), Double.toString(pr.getSubtotal()), Double.toString(pr.getTotal())};  
                    modelorder_pursup.addRow(obpro);
                System.out.println("mostrando");
            }

        } catch (SQLException ex) {
            System.out.println("error:" + ex);
        }
    }

    public void getlistDefault_purchase_supplier(DefaultTableModel modelcompra) {

//        DefaultTableModel modeloventas = (DefaultTableModel) frames.MnBaseAdmin.tablaVenta.getModel();
//        while (modeloventas.getRowCount() > 0) {
//            modeloventas.removeRow(0);
//        }
        String sql = "";
        sql = "SELECT * FROM list_purchase_supplier()";
Purchase_suppliers purcha_sup = null;
        ArrayList< Purchase_suppliers> li_purc_sup = new ArrayList();
        try {
            Statement st = super.getConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                purcha_sup = new  Purchase_suppliers();
                purcha_sup.setPurchase_id(rs.getInt("purchase_id"));
                purcha_sup.setPurchase_date(rs.getDate("purchase_date"));
                purcha_sup.setPurchase_status(rs.getInt("purchase_status"));
                purcha_sup.setObservation(rs.getString("observations"));
                purcha_sup.setSubtotal(rs.getDouble("subtotal"));
                purcha_sup.setIva(rs.getDouble("iva"));
                purcha_sup.setTotal(rs.getDouble("total"));
               li_purc_sup.add(purcha_sup);
            }

            for (Purchase_suppliers pr : li_purc_sup) {  
                    String obpro[] = {Integer.toString(pr.getPurchase_id()),sdf.format(pr.getPurchase_date()), Double.toString(pr.getSubtotal()), Double.toString(pr.getTotal())}; 
                    modelcompra.addRow(obpro);
                System.out.println("mostrando");
            }

        } catch (SQLException ex) {
            System.out.println("error:" + ex);
        }
    }
}
