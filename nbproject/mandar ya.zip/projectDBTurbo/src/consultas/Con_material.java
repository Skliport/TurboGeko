/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consultas;

import entidades.Finished_product;
import entidades.Material;
import entidades.Sale;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author William
 */
public class Con_material extends Conexion {

    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
    private int ordbyfp;

    public void getlist_materialfilter(DefaultTableModel modelmaterial,String buscar) {
        
        String sql = "";
        sql = "SELECT * FROM material_stock_filterw('"+buscar+"');";

        Material mate = null;
        ArrayList<Material> list_material = new ArrayList();
        try {
            Statement st = super.getConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                mate = new Material();
                mate.setId_material(rs.getInt("material_id"));
                mate.setSupplier_name(rs.getString("supplier_name"));
                mate.setMateril_name(rs.getString("material_name"));
                mate.setUnits_in_stock(rs.getInt("units_in_stock"));
                mate.setMaterial_measure(rs.getString("material_measure"));
                mate.setUnit_price(rs.getDouble("unit_price"));
                mate.setNumber_lot(rs.getInt("number_lot"));
                mate.setExpiration_date(rs.getDate("expiration_date"));
                mate.setDiscountinued(rs.getInt("discontinued"));
                list_material.add(mate);
            }

            for (Material mat : list_material) {
                String obpro[] = {Integer.toString(mat.getId_material()), mat.getMateril_name(),mat.getSupplier_name(), mat.getMaterial_measure(), Integer.toString(mat.getDiscountinued()),
                    Double.toString(mat.getUnit_price()),Integer.toString(mat.getUnits_in_stock())};
                modelmaterial.addRow(obpro);
            }

        } catch (SQLException ex) {
            System.out.println("error:" + ex);
        }
    }

    public void getlistDefaultfmaterialstock(DefaultTableModel modelmaterial) {

//        DefaultTableModel modeloventas = (DefaultTableModel) frames.MnBaseAdmin.tablaVenta.getModel();
//        while (modeloventas.getRowCount() > 0) {
//            modeloventas.removeRow(0);
//        }
        String sql = "";
        sql = "SELECT * FROM  material_stock();";

        Material mate = null;
        ArrayList<Material> list_material = new ArrayList();

        try {
            Statement st = super.getConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                mate = new Material();
                mate.setId_material(rs.getInt("material_id"));
                mate.setSupplier_name(rs.getString("supplier_name"));
                mate.setMateril_name(rs.getString("material_name"));
                mate.setUnits_in_stock(rs.getInt("units_in_stock"));
                mate.setMaterial_measure(rs.getString("material_measure"));
                mate.setUnit_price(rs.getDouble("unit_price"));
                mate.setNumber_lot(rs.getInt("number_lot"));
                mate.setExpiration_date(rs.getDate("expiration_date"));
                mate.setDiscountinued(rs.getInt("discontinued"));
                list_material.add(mate);
            }

            for (Material mat : list_material) {
                String obpro[] = {Integer.toString(mat.getId_material()), mat.getMateril_name(), mat.getSupplier_name(),mat.getMaterial_measure(), Integer.toString(mat.getDiscountinued()),
                     Double.toString(mat.getUnit_price()),Integer.toString(mat.getUnits_in_stock())};
                modelmaterial.addRow(obpro);
            }

        } catch (SQLException ex) {
            System.out.println("error:" + ex);
        }
    }

}
