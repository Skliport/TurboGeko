/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consultas;

import entidades.Sale;
import entidades.Sale_detail;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author William
 */
public class Con_sale_detail extends Conexion {

    public void getlist_saledetail(DefaultTableModel modelsale_detail ,int id_venta) {
//
//        DefaultTableModel modeloventas = (DefaultTableModel) frames.MnBaseAdmin.tablaVenta.getModel();
//        while (modeloventas.getRowCount() > 0) {
//            modeloventas.removeRow(0);
//        }
        String sql = "";
        sql = "SELECT * FROM list_sale_detail_OUT('" + id_venta + "')";

        Sale_detail saled = null;
        ArrayList<Sale_detail> lisaledet = new ArrayList();
        try {
            Statement st = super.getConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                saled = new Sale_detail();
                saled.setId_sale_detail(rs.getInt("sale_detail"));
                saled.setDiscount(rs.getDouble("discount"));
                saled.setAmount(rs.getDouble("amount"));
                saled.setName_fproduct(rs.getString("name_product"));
                saled.setFproduct_price(rs.getDouble("unit_price"));
                lisaledet.add(saled);
            }
            double total;
            for (Sale_detail pr : lisaledet) {
                total=pr.getAmount()* pr.getFproduct_price();
                String obpro[] = {Integer.toString(pr.getId_sale_detail()) ,pr.getName_fproduct(),Double.toString(pr.getFproduct_price()),
                    Double.toString(pr.getDiscount()),Double.toString(pr.getAmount()) ,Double.toString(total)};  
                modelsale_detail.addRow(obpro);
            }
        } catch (SQLException ex) {
            System.out.println("error:" + ex);
        }
    }

}
