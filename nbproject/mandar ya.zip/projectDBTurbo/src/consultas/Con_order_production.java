/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consultas;

import entidades.Order_production;
import entidades.Sale;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author William
 */
public class Con_order_production extends Conexion {

    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

    public void getlistjorderproduct_filter(DefaultTableModel modelorder_prodt, String buscar) {
//        DefaultTableModel modeloventas = (DefaultTableModel) frames.MnBaseAdmin.tablaVenta.getModel();
//        while (modeloventas.getRowCount() > 0) {
//            modeloventas.removeRow(0);
//        }
        String sql = "";
        sql = "SELECT * FROM listorder_production_filter('" + buscar + "')";
        
             Order_production ord_p = null;
        ArrayList< Order_production> liord_p = new ArrayList();
        try {
            Statement st = super.getConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ord_p = new  Order_production();
                ord_p.setId_order_production(rs.getInt("order_production_id"));
                ord_p.setFirstname_customer(rs.getString("first_name"));
                ord_p.setLastname_customer(rs.getString("last_name"));
                ord_p.setOrder_prod_date(rs.getDate("order_prod_date"));
                ord_p.setOrder_state(rs.getInt("order_state"));
                ord_p.setCustomer_dui(rs.getString("dui"));
                ord_p.setCustomer_nit(rs.getString("nit"));
                ord_p.setCustomer_telephone(rs.getString("telephone"));
                liord_p.add(ord_p);
            }

            for (Order_production pr : liord_p) {  
                    String obpro[] = {Integer.toString(pr.getId_order_production()) , pr.getFirstname_customer()+ pr.getLastname_customer(),
                    sdf.format(pr.getOrder_prod_date()) , Double.toString(pr.getTotal()), Integer.toString(pr.getOrder_state())}; 
                    modelorder_prodt.addRow(obpro);
                System.out.println("mostrando");
            }

        } catch (SQLException ex) {
            System.out.println("error:" + ex);
        }
    }

    public void getlistDefault_ordeproduction(DefaultTableModel modelsale) {

//        DefaultTableModel modeloventas = (DefaultTableModel) frames.MnBaseAdmin.tablaVenta.getModel();
//        while (modeloventas.getRowCount() > 0) {
//            modeloventas.removeRow(0);
//        }
        String sql = "";
        sql = "SELECT * FROM listorder_production()";
             Order_production ord_p = null;
        ArrayList< Order_production> liord_p = new ArrayList();
        try {
            Statement st = super.getConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ord_p = new  Order_production();
                ord_p.setId_order_production(rs.getInt("order_production_id"));
                ord_p.setFirstname_customer(rs.getString("first_name"));
                ord_p.setLastname_customer(rs.getString("last_name"));
                ord_p.setOrder_prod_date(rs.getDate("order_prod_date"));
                ord_p.setOrder_state(rs.getInt("order_state"));
                ord_p.setCustomer_dui(rs.getString("dui"));
                ord_p.setCustomer_nit(rs.getString("nit"));
                ord_p.setCustomer_telephone(rs.getString("telephone"));
                liord_p.add(ord_p);
            }

            for (Order_production pr : liord_p) {  
                    String obpro[] = {Integer.toString(pr.getId_order_production()) , pr.getFirstname_customer()+ pr.getLastname_customer(),
                    sdf.format(pr.getOrder_prod_date()) , Double.toString(pr.getTotal()), Integer.toString(pr.getOrder_state())}; 
                    modelsale.addRow(obpro);
                System.out.println("mostrando");
            }

        } catch (SQLException ex) {
            System.out.println("error:" + ex);
        }
    }
}
