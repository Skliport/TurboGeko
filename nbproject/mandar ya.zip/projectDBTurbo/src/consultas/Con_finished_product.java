/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consultas;

import entidades.Finished_product;
import entidades.Sale;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author William
 */
public class Con_finished_product extends Conexion{
    
    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
    private int ordbyfp;
    public void getlistsales_filter(DefaultTableModel modelfproduct, String buscar) {
//
//        DefaultTableModel modeloventas = (DefaultTableModel) frames.MnBaseAdmin.tablaVenta.getModel();
//        while (modeloventas.getRowCount() > 0) {
//            modeloventas.removeRow(0);
//        }
        String sql = "";
        sql = "SELECT * FROM product_stock_filter('"+buscar+"');";

        Finished_product fproduct = null;
        ArrayList<Finished_product> lif_products = new ArrayList();
        try {
            Statement st = super.getConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                fproduct = new Finished_product();
                fproduct.setId_finished_product(rs.getInt("id_finished_product"));
                fproduct.setName_product(rs.getString("name_product"));
                fproduct.setDiscountinued(rs.getInt("discontinued"));
                fproduct.setUnits_in_stock(rs.getInt("units_in_stock"));
                fproduct.setManufacture_date(rs.getDate("manufacture_date")); 
                fproduct.setUnit_price(rs.getDouble("unit_price"));
                fproduct.setQuantity(rs.getInt("quantity"));
                fproduct.setTotal(rs.getDouble("total"));
                lif_products.add(fproduct);
            }

            for (Finished_product pr : lif_products) {
                String obpro[] = {Integer.toString(pr.getId_finished_product()), pr.getName_product(), Integer.toString(pr.getDiscountinued()),
                sdf.format(pr.getManufacture_date()), Double.toString(pr.getUnit_price()),Integer.toString(pr.getUnits_in_stock())  }; 
                modelfproduct.addRow(obpro);
            }

        } catch (SQLException ex) {
            System.out.println("error:" + ex);
        }
    }
    
     public void getlistDefaultfprodstock( DefaultTableModel modelfproduc) {

//        DefaultTableModel modeloventas = (DefaultTableModel) frames.MnBaseAdmin.tablaVenta.getModel();
//        while (modeloventas.getRowCount() > 0) {
//            modeloventas.removeRow(0);
//        }
        String sql = "";
        sql = "select * from listar_finished_product();";

        Finished_product fproduct = null;
        ArrayList<Finished_product> lif_products = new ArrayList();
        try {
            Statement st = super.getConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                fproduct = new Finished_product();
                fproduct.setId_finished_product(rs.getInt("id_finished_product"));
                fproduct.setName_product(rs.getString("name_product"));
                fproduct.setDiscountinued(rs.getInt("discontinued"));
                fproduct.setUnits_in_stock(rs.getInt("units_in_stock"));
                fproduct.setManufacture_date(rs.getDate("manufacture_date")); 
                fproduct.setUnit_price(rs.getDouble("unit_price"));
                fproduct.setQuantity(rs.getInt("quantity"));
                fproduct.setTotal(rs.getDouble("total"));
                lif_products.add(fproduct);
            }

            for (Finished_product pr : lif_products) {
                String obpro[] = {Integer.toString(pr.getId_finished_product()), pr.getName_product(), Integer.toString(pr.getDiscountinued()),
                sdf.format(pr.getManufacture_date()), Double.toString(pr.getUnit_price()),Integer.toString(pr.getUnits_in_stock())  }; 
                modelfproduc.addRow(obpro);
            }

        } catch (SQLException ex) {
            System.out.println("error:" + ex);
        }
    }
    
}
