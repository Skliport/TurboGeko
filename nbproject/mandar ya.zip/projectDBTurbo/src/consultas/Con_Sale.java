/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consultas;

import entidades.Sale;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author William
 */
public class Con_Sale extends Conexion{
    
    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
    
    public void getlistsales_filter(DefaultTableModel modelsales,String buscar) {
//        DefaultTableModel modeloventas = (DefaultTableModel) frames.MnBaseAdmin.tablaVenta.getModel();
//        while (modeloventas.getRowCount() > 0) {
//            modeloventas.removeRow(0);
//        }
         String sql = "";
        sql = "SELECT * FROM sales_filter('" + buscar + "')";

        Sale vent = null;
        ArrayList<Sale> liventa = new ArrayList();
        try {
            Statement st = super.getConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                vent = new Sale();
                vent.setId_sale(rs.getInt("id_sale"));
                vent.setNum_invoice(rs.getString("num_invoice"));
                vent.setStatus_sale(rs.getInt("status_sale")); 
                vent.setDate_sale(rs.getString("date_sale"));
//                vent.setShip_date(rs.getString("cli.noCe"));
//                vent.setDocument_type(rs.getInt("total")); 
                vent.setSubtotal(rs.getDouble("sub_total"));
                vent.setTax(rs.getDouble("tax"));
                vent.setTotal(rs.getDouble("total"));
//                vent.setObservation(rs.getString(""));
//                vent.setId_sale(rs.getInt(""));
                vent.setCus_first_name(rs.getString("first_name"));
                vent.setCus_last_name(rs.getString("last_name"));
                vent.setCus_dui(rs.getString("dui"));
                vent.setCus_nit(rs.getString("nit"));
                vent.setCus_mobile(rs.getString("mobile"));
                vent.setCus_email(rs.getString("email"));
                liventa.add(vent);
            }

            for (Sale pr : liventa) {
                String obpro[] = {Integer.toString(pr.getId_sale()),"cancelado", pr.getDate_sale(),
                Double.toString(pr.getSubtotal()),Double.toString(pr.getTax()),Double.toString(pr.getTotal()),pr.getCus_first_name()+" "+pr.getCus_last_name()}; 
                modelsales.addRow(obpro);  
            }

        } catch (SQLException ex) {
            System.out.println("error:" + ex);
        }
    }
    
     public void getlistDefaultVents( DefaultTableModel modelsale) {

//        DefaultTableModel modeloventas = (DefaultTableModel) frames.MnBaseAdmin.tablaVenta.getModel();
//        while (modeloventas.getRowCount() > 0) {
//            modeloventas.removeRow(0);
//        }
        String sql = "";
        sql = "select * from list_sales()";

        Sale vent = null;
        ArrayList<Sale> liventa = new ArrayList();
        try {
            Statement st = super.getConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                vent = new Sale();
                vent.setId_sale(rs.getInt("id_sale"));
                vent.setNum_invoice(rs.getString("num_invoice"));
                vent.setStatus_sale(rs.getInt("status_sale")); 
                vent.setDate_sale(rs.getString("date_sale"));
                vent.setShip_date(rs.getString("ship_date"));
                vent.setDocument_type(rs.getInt("document_type")); 
                vent.setSubtotal(rs.getDouble("sub_total"));
                vent.setTax(rs.getDouble("tax"));
                vent.setTotal(rs.getDouble("total"));
                vent.setObservation(rs.getString("observations"));
//                vent.setId_sale(rs.getInt(""));
                liventa.add(vent);
            }

            for (Sale pr : liventa) {
                if (pr.getStatus_sale()==1) {
                String obpro[] = {Integer.toString(pr.getId_sale()),"cancelado", pr.getDate_sale(),
                Double.toString(pr.getSubtotal()),Double.toString(pr.getTax()),Double.toString(pr.getTotal())}; 
                modelsale.addRow(obpro);   
                }
                else{
                String obpro[] = {Integer.toString(pr.getId_sale()),"sin pago", pr.getDate_sale(),
                Double.toString(pr.getSubtotal()),Double.toString(pr.getTax()),Double.toString(pr.getTotal())}; 
                modelsale.addRow(obpro); 
                }
            }

        } catch (SQLException ex) {
            System.out.println("error:" + ex);
        }
    }
}
