/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

/**
 *
 * @author william
 */
public class Purchase_suppliers_details {
    private int purchase_suppliers_details,purchase,material_id,quantity;
    private double unit_price; 
    private String material_name;

    public String getMaterial_name() {
        return material_name;
    }

    public void setMaterial_name(String material_name) {
        this.material_name = material_name;
    }
    

    public int getPurchase_suppliers_details() {
        return purchase_suppliers_details;
    }

    public void setPurchase_suppliers_details(int purchase_suppliers_details) {
        this.purchase_suppliers_details = purchase_suppliers_details;
    }

    public int getPurchase() {
        return purchase;
    }

    public void setPurchase(int purchase) {
        this.purchase = purchase;
    }

    public int getMaterial_id() {
        return material_id;
    }

    public void setMaterial_id(int material_id) {
        this.material_id = material_id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getUnit_price() {
        return unit_price;
    }

    public void setUnit_price(double unit_price) {
        this.unit_price = unit_price;
    }
    
    
}
