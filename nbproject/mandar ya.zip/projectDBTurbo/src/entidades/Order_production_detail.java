/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

/**
 *
 * @author William
 */
public class Order_production_detail {
    private int id_order_production_detail;
    private  String recipe;
    private  double quantity;
    private double unit_price;
    private int id_order_production;
    private String product_name;

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }
    
    
    public int getId_order_production_detail() {
        return id_order_production_detail;
    }

    public void setId_order_production_detail(int id_order_production_detail) {
        this.id_order_production_detail = id_order_production_detail;
    }

    public String getRecipe() {
        return recipe;
    }

    public void setRecipe(String recipe) {
        this.recipe = recipe;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public double getUnit_price() {
        return unit_price;
    }

    public void setUnit_price(double unit_price) {
        this.unit_price = unit_price;
    }

    public int getId_order_production() {
        return id_order_production;
    }

    public void setId_order_production(int id_order_production) {
        this.id_order_production = id_order_production;
    }
    
    
}
