/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.util.Date;

/**
 *
 * @author William
 */
public class Finished_product {
    private int id_finished_product;
    private String name_product;
    private int units_in_stock;
    private double unit_price;
    private int quantity;
    private int discountinued;
    private Date manufacture_date;
    private double total;

    public int getId_finished_product() {
        return id_finished_product;
    }

    public void setId_finished_product(int id_finished_product) {
        this.id_finished_product = id_finished_product;
    }



    public String getName_product() {
        return name_product;
    }

    public void setName_product(String name_product) {
        this.name_product = name_product;
    }

    public int getUnits_in_stock() {
        return units_in_stock;
    }

    public void setUnits_in_stock(int units_in_stock) {
        this.units_in_stock = units_in_stock;
    }

    public double getUnit_price() {
        return unit_price;
    }

    public void setUnit_price(double unit_price) {
        this.unit_price = unit_price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getDiscountinued() {
        return discountinued;
    }

    public void setDiscountinued(int discountinued) {
        this.discountinued = discountinued;
    }

    public Date getManufacture_date() {
        return manufacture_date;
    }

    public void setManufacture_date(Date manufacture_date) {
        this.manufacture_date = manufacture_date;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    
    
}
