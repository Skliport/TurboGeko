/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.util.Date;

/**
 *
 * @author William
 */
public class Material {
    private int id_material;
    private  String supplier_name;
    private  String materil_name;
    private int units_in_stock;
    private String material_measure;
    private double unit_price;
    private int number_lot;
    private Date expiration_date;
    private int discountinued;

    public int getId_material() {
        return id_material;
    }

    public void setId_material(int id_material) {
        this.id_material = id_material;
    }

    public String getSupplier_name() {
        return supplier_name;
    }

    public void setSupplier_name(String supplier_name) {
        this.supplier_name = supplier_name;
    }

    public String getMateril_name() {
        return materil_name;
    }

    public void setMateril_name(String materil_name) {
        this.materil_name = materil_name;
    }

    public int getUnits_in_stock() {
        return units_in_stock;
    }

    public void setUnits_in_stock(int units_in_stock) {
        this.units_in_stock = units_in_stock;
    }

    public String getMaterial_measure() {
        return material_measure;
    }

    public void setMaterial_measure(String material_measure) {
        this.material_measure = material_measure;
    }

    public double getUnit_price() {
        return unit_price;
    }

    public void setUnit_price(double unit_price) {
        this.unit_price = unit_price;
    }

    public int getNumber_lot() {
        return number_lot;
    }

    public void setNumber_lot(int number_lot) {
        this.number_lot = number_lot;
    }

    public Date getExpiration_date() {
        return expiration_date;
    }

    public void setExpiration_date(Date expiration_date) {
        this.expiration_date = expiration_date;
    }

    public int getDiscountinued() {
        return discountinued;
    }

    public void setDiscountinued(int discountinued) {
        this.discountinued = discountinued;
    }
    
    
}
