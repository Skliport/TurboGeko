/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.util.Date;

/**
 *
 * @author William
 */
public class Sale {
    private int id_sale;
    private String num_invoice;
    private int status_sale;
    private String ship_date; 
    private int document_type;
    private double subtotal;
    private double tax;
    private double total;
    private String observation;
    private int id_customer;
    private String name_customer;
    private String date_sale;
    private String cus_first_name;
    private String cus_last_name;
    private String cus_dui;
    private String cus_nit;
    private String cus_mobile;
    private String cus_email;

    public String getCus_dui() {
        return cus_dui;
    }

    public void setCus_dui(String cus_dui) {
        this.cus_dui = cus_dui;
    }

    public String getCus_nit() {
        return cus_nit;
    }

    public void setCus_nit(String cus_nit) {
        this.cus_nit = cus_nit;
    }

    public String getCus_mobile() {
        return cus_mobile;
    }

    public void setCus_mobile(String cus_mobile) {
        this.cus_mobile = cus_mobile;
    }

    public String getCus_email() {
        return cus_email;
    }

    public void setCus_email(String cus_email) {
        this.cus_email = cus_email;
    }

    public String getCus_first_name() {
        return cus_first_name;
    }

    public void setCus_first_name(String cus_first_name) {
        this.cus_first_name = cus_first_name;
    }

    public String getCus_last_name() {
        return cus_last_name;
    }

    public void setCus_last_name(String cus_last_name) {
        this.cus_last_name = cus_last_name;
    }
    

    public String getDate_sale() {
        return date_sale;
    }

    public void setDate_sale(String date_sale) {
        this.date_sale = date_sale;
    }
    
    

    public int getId_sale() {
        return id_sale;
    }

    public void setId_sale(int id_sale) {
        this.id_sale = id_sale;
    }

   

    public String getNum_invoice() {
        return num_invoice;
    }

    public void setNum_invoice(String num_invoice) {
        this.num_invoice = num_invoice;
    }

    public int getStatus_sale() {
        return status_sale;
    }

    public void setStatus_sale(int status_sale) {
        this.status_sale = status_sale;
    }

    public String getShip_date() {
        return ship_date;
    }

    public void setShip_date(String ship_date) {
        this.ship_date = ship_date;
    }

    public int getDocument_type() {
        return document_type;
    }

    public void setDocument_type(int document_type) {
        this.document_type = document_type;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getTax() {
        return tax;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getObservation() {
        return observation;
    }

    public void setObservation(String observation) {
        this.observation = observation;
    }

    public int getId_customer() {
        return id_customer;
    }

    public void setId_customer(int id_customer) {
        this.id_customer = id_customer;
    }

    public String getName_customer() {
        return name_customer;
    }

    public void setName_customer(String name_customer) {
        this.name_customer = name_customer;
    }
    
    
}






























