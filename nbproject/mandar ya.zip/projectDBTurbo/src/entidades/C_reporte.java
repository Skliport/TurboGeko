/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import consultas.Conexion;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author Jorge Isaac
 */
public class C_reporte extends Conexion {

    public void showreports(String ruta, String titulo) {
        try {
            JasperReport reporte = (JasperReport) JRLoader.loadObject(getClass().getResource(ruta)); 
            JasperPrint print = JasperFillManager.fillReport(reporte, null, super.getConexion());
            int n = print.getPages().size();
            if (n > 0) {
            JasperViewer mostrarreporte = new JasperViewer(print, false);
            mostrarreporte.setVisible(true);
            mostrarreporte.setTitle(titulo);
            mostrarreporte.setSize(900, 650);
               mostrarreporte.setZoomRatio((float) 0.6);
            }else{
                JOptionPane.showMessageDialog(null, "NO hay datos ","mensaje del sistema", JOptionPane.INFORMATION_MESSAGE);
            }
            System.out.println("abriendo reporte");
        } catch (JRException ex) {
            Logger.getLogger(C_reporte.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("error del reporte");
        }
 
    }
    public void showreportparameter(String ruta, String title,int parameter){
        try {
            Map parametro= new HashMap();
            parametro.put("id_venta", parameter);
            JasperReport report= (JasperReport) JRLoader.loadObject(getClass().getResource(ruta));
            JasperPrint print = JasperFillManager.fillReport(report,parametro,super.getConexion());
//            int npag= print.getPages().size();
//            if (npag>0) {
                System.out.println("abriendo reporte");
                JasperViewer mostrarreport= new JasperViewer(print, false);
                mostrarreport.setTitle(title); 
                mostrarreport.setVisible(true); 
//                mostrarreport.setZoomRatio((float) 0.7);
//            }else{
//            JOptionPane.showMessageDialog(null,"No hay datoa a cargar","System message",JOptionPane.INFORMATION_MESSAGE);
//            }
        
        } catch (JRException ex) {
            System.out.println("nos puedo abrier error:"+ex);
            Logger.getLogger(C_reporte.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
}
