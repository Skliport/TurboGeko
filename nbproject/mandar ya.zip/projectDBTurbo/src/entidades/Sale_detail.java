/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

/**
 *
 * @author William
 */
public class Sale_detail {

    private int id_sale_detail;
    private double discount;
    private double amount;
    private int id_sale;
    private int id_finished_product;
    private String name_fproduct;
    private double fproduct_price;

    public double getFproduct_price() {
        return fproduct_price;
    }

    public void setFproduct_price(double fproduct_price) {
        this.fproduct_price = fproduct_price;
    }
    
    
    
    public int getId_sale_detail() {
        return id_sale_detail;
    }

    public void setId_sale_detail(int id_sale_detail) {
        this.id_sale_detail = id_sale_detail;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getId_sale() {
        return id_sale;
    }

    public void setId_sale(int id_sale) {
        this.id_sale = id_sale;
    }

    public int getId_finished_product() {
        return id_finished_product;
    }

    public void setId_finished_product(int id_finished_product) {
        this.id_finished_product = id_finished_product;
    }

    public String getName_fproduct() {
        return name_fproduct;
    }

    public void setName_fproduct(String name_fproduct) {
        this.name_fproduct = name_fproduct;
    }
    
    

}
