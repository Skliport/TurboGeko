/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.util.Date;

/**
 *
 * @author William
 */
public class Order_production {
    private int id_order_production;
    private Date order_prod_date;
    private double total;
    private int order_state;
    private String firstname_customer;
    private String lastname_customer;
private String customer_dui;
        private String customer_nit;
        private String customer_telephone;

    public String getCustomer_telephone() {
        return customer_telephone;
    }

    public void setCustomer_telephone(String customer_telephone) {
        this.customer_telephone = customer_telephone;
    }
        

    public String getCustomer_dui() {
        return customer_dui;
    }

    public void setCustomer_dui(String customer_dui) {
        this.customer_dui = customer_dui;
    }

    public String getCustomer_nit() {
        return customer_nit;
    }

    public void setCustomer_nit(String customer_nit) {
        this.customer_nit = customer_nit;
    }
        
    
    public int getId_order_production() {
        return id_order_production;
    }

    public void setId_order_production(int id_order_production) {
        this.id_order_production = id_order_production;
    }

    public Date getOrder_prod_date() {
        return order_prod_date;
    }

    public void setOrder_prod_date(Date order_prod_date) {
        this.order_prod_date = order_prod_date;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public int getOrder_state() {
        return order_state;
    }

    public void setOrder_state(int order_state) {
        this.order_state = order_state;
    }

    public String getFirstname_customer() {
        return firstname_customer;
    }

    public void setFirstname_customer(String firstname_customer) {
        this.firstname_customer = firstname_customer;
    }

    public String getLastname_customer() {
        return lastname_customer;
    }

    public void setLastname_customer(String lastname_customer) {
        this.lastname_customer = lastname_customer;
    }

            
            
}
