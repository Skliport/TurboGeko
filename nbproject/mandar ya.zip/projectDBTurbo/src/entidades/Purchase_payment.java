/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.util.Date;

/**
 *
 * @author william
 */
public class Purchase_payment {
    private int purchase_payment_id,purchase_id,payment_status_id;
    private double total,paid_amount;
    private Date due_date;
    private String payment_date;

    public int getPurchase_payment_id() {
        return purchase_payment_id;
    }

    public void setPurchase_payment_id(int purchase_payment_id) {
        this.purchase_payment_id = purchase_payment_id;
    }

    public int getPurchase_id() {
        return purchase_id;
    }

    public void setPurchase_id(int purchase_id) {
        this.purchase_id = purchase_id;
    }

    public int getPayment_status_id() {
        return payment_status_id;
    }

    public void setPayment_status_id(int payment_status_id) {
        this.payment_status_id = payment_status_id;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getPaid_amount() {
        return paid_amount;
    }

    public void setPaid_amount(double paid_amount) {
        this.paid_amount = paid_amount;
    }

    public Date getDue_date() {
        return due_date;
    }

    public void setDue_date(Date due_date) {
        this.due_date = due_date;
    }

    public String getPayment_date() {
        return payment_date;
    }

    public void setPayment_date(String payment_date) {
        this.payment_date = payment_date;
    }
    
}
